const express = require('express');
const cors = require('cors');
require("dotenv").config();
const app = express();
const port = process.env.PORT || 5000;
const cron = require("node-cron");
const moment = require("moment-timezone");
app.use(cors(
  {
    origin: [
      "http://localhost:5173",
      "http://localhost:5174",
      // "https://domain-hub-a81ae.web.app",
      "https://imc.suhadahmodkhan.com",
    ],
    credentials: true,
  }
))
app.use(express.json())

const { MongoClient, ServerApiVersion , ObjectId } = require('mongodb');
const uri = `mongodb+srv://${process.env.DB_NAME}:${process.env.DB_PASS}@cluster0.5y6t7ws.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`;

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

async function run() {
  try {
    // Connect the client to the server	(optional starting in v4.7)
    // await client.connect();
    // create test api start
    const usersCollection = client.db("imcDB").collection("users");
    app.post("/users", async (req, res) => {
      const user = req.body;
      const email = req.body.email;
      const cursor = { email: email };
      const existing = await usersCollection.findOne(cursor);

      if (existing) {
        return res.status(400).send({ message: "User already exists" });
      } else {
        const result = await usersCollection.insertOne(user);
        res.send(result);
      }
    });
    app.post("/make-admin", async (req, res) => {
      const user = req.body;
      const email = req.body.email;
      const cursor = { email: email };
      const existing = await usersCollection.findOne(cursor);

      if (existing) {
        return res.status(400).send({ message: "User already exists" });
      } else {
        const result = await usersCollection.insertOne(user);
        res.send(result);
      }
    });
    app.get("/all-users", async (req, res) => {
      const result = await usersCollection.find({$or: [
        { role: "student" }, // Notice sent to all batches
        { role: "teacher" }, // Notice sent to specific matching batch
      ],}).toArray();
     
      res.send(result.reverse());
    });
    app.get("/admin-users", async (req, res) => {
      const result = await usersCollection.find({role : 'admin'}).toArray();
     
      res.send(result.reverse());
    });
    app.get("/users-create", async (req, res) => {
      const email = req.query.email;
      const password =req.query.password;
      const role = req.query.role;
      const cursor = { email: email,defaultPassword :password,role :role };
      const result = await usersCollection.findOne(cursor);
//
      if (result) {
        return res.send(result);
      } else {
        return res.status(401).send({ message: "You can not create account , inform admin " });
      }
    });
      app.get("/users", async (req, res) => {
        const result = await usersCollection.find().toArray();
       
        res.send(result);
      });
  
      app.get("/users/:id", async (req, res) => {
        const id = req.params.id;
        const query = { _id: new ObjectId(id) };
        const result = await usersCollection.findOne(query);
        res.send(result);
      });
      app.delete("/users/:id", async (req, res) => {
        const id = req.params.id;
        const query = { _id: new ObjectId(id) };
        const result = await usersCollection.deleteOne(query);
        res.send(result);
      });
      app.get("/userInfo", async (req, res) => {

        const email = req.query.email;
        const cursor = { email: email };
        const result = await usersCollection.findOne(cursor);
        res.send(result);
       
      });
      app.patch('/users/:email' , async(req , res) => {
        const email = req.params.email ;
        const filter = { email :email }
        const update = req.body ;
        const updateDoc = {
       
            $set: {
              displayName:  update.displayName,
              photoURL:  update.photoURL,
            mobile:  update.mobile,
         
    
            },
          };
        const result = await usersCollection.updateOne(filter , updateDoc )
        res.send(result)
    })
      app.patch('/users/:email' , async(req , res) => {
        const email = req.params.email ;
        const filter = { email :email }
        const update = req.body ;
        const updateDoc = {
       
            $set: {
              displayName:  update.displayName,
              photoURL:  update.photoURL,
            mobile:  update.mobile,
         
    
            },
          };
        const result = await usersCollection.updateOne(filter , updateDoc )
        res.send(result)
    })
      app.patch('/users-password-change/:email' , async(req , res) => {
        const email = req.params.email ;
        const filter = { email :email }
        const update = req.body ;
        const updateDoc = {
       
            $set: {
              defaultPassword:  update.defaultPassword,
            },
          };
        const result = await usersCollection.updateOne(filter , updateDoc )
        res.send(result)
    })
      app.patch('/users-email-change/:email' , async(req , res) => {
        const email = req.params.email ;
        const filter = { email :email }
        const user = await usersCollection.findOne(filter)
        const update = req.body ;
          const updateDoc = {
         
              $set: {
                email:  update.email,
              },
            };

        if(user?.role === 'teacher' ){
         const result = await instructorCollection.updateOne(filter , updateDoc )
         const resultuser = await usersCollection.updateOne(filter , updateDoc )
         return res.send(result)
        }
        if(user?.role === 'student' ){
         const result = await admissionCollection.updateOne(filter , updateDoc )
         const resultuser = await usersCollection.updateOne(filter , updateDoc )
         return res.send(result)
        }
        
    })
    // batches start
    const batchCollection = client.db("imcDB").collection("batches");
    app.post("/batches", async (req, res) => {
      const batch = req.body;

      const result = await batchCollection.insertOne(batch);
      res.send(result);
    });
    app.get("/filter-batches", async (req, res) => {
      const { name } = req.query; // Capture 'name' from query parameters
    console.log(name);
      // Define the search condition, allowing for search on courseName, batchTitle, or status
      const query = name ? {
        $or: [  // Match courseName
          { batchTitle: { $regex: name, $options: "i" } },  // Match batchTitle
          { status: { $regex: name, $options: "i" } },      // Match status
        ]
      } : {}; // If no 'name' query parameter, return all records
    
      try {
        // Query the database based on the search conditions
        let result = (await batchCollection.find(query).toArray()).reverse();
        for (const batch of result) {
          // Assuming `batch._id` is the unique identifier for the batch
          const studentCount = await admissionCollection.countDocuments({
            batch: batch.batchTitle, // Match students assigned to this batch
          });
          batch.totalStudents = studentCount; // Add the totalStudents property
        }
        res.send(result); // Send the filtered batches as the response
      } catch (error) {
        console.error(error);
        res.status(500).send({ error: 'Failed to fetch batches' });
      }
    });
    app.get("/batches/:id", async (req, res) => {
      const query = req.params.id ;
      const filter = { _id: new ObjectId(query) }
      const result = await batchCollection.findOne(filter)
      res.send(result)
    })
    app.get("/batches", async (req, res) => {
      const query = req.query.id ;
      const filter = { batchTitle: query }
      const result = await batchCollection.findOne(filter)
      res.send(result)
    })
    app.delete("/batches/:id", async (req, res) => {
      const query = req.params.id ;
      const filter = { _id: new ObjectId(query) }
      const result = await batchCollection.deleteOne(filter)
      res.send(result)
    })
    app.patch('/batches/:id' , async(req , res) => {
      const id = req.params.id ;
      const filter = { _id :new ObjectId(id) }
      const update = req.body ;
      const updateDoc = {
     
          $set: {
            batchTitle:  update.batchTitle,
            classTime:  update.classTime,
            studentClass:  update.studentClass,
            classDay:  update.classDay,
            startDate:  update.startDate,
            status:  update.status,
            batchMonthlyFee:  update.batchMonthlyFee,
            batchModelTestFee:  update.batchModelTestFee,

           
            
          },
        };
      const result = await batchCollection.updateOne(filter , updateDoc )
      res.send(result)
  })
    // batches end

    const createTestCollection = client.db("imcDB").collection("create-tests");
    app.post("/createTests", async (req, res) => {
      const formInfo = req.body;
      console.log(formInfo);
      const result = await createTestCollection.insertOne(formInfo);
      res.send(result);
    });
    app.get("/createTests", async (req, res) => {
      const result = await createTestCollection.find().toArray();
      res.send(result)
    })
    app.get("/createTests/:id", async (req, res) => {
      const query = req.params.id ;
      const filter = { _id: new ObjectId(query) }
      const result = await createTestCollection.findOne(filter)
      res.send(result)
    })
    app.get("/tests/lastindex", async (req, res) => {
      const index = await createTestCollection.find().toArray()
      const lastIndex = index.length - 1
      console.log(index);
      const lastObject = index[lastIndex]
      const filter = {_id : new ObjectId(lastObject._id)}
      const result = await createTestCollection.findOne(filter)
      res.send(result)
    })
    app.get("/createTests/allStudents/:id", async (req, res) => {
      const query = req.params.id ;
      console.log(query);
      const filter = { _id: new ObjectId(query) }
      const testInfo = await createTestCollection.findOne(filter)
      console.log(testInfo );
      const queryStudentClass = {studentClass : testInfo?.testClass}
      const students = await admissionCollection.find(queryStudentClass).toArray()
      const result = { testInfo, students}
      console.log(result );
      res.send(result)
    })
    app.delete("/createTests/:id" , async (req,res) => {
      const id = req.params.id ;
      const query = { _id : new ObjectId(id)}
      const result = await createTestCollection.deleteOne(query);
      res.send(result)
    })
    // create test api end
    // marks code api start
    const marksCollection = client.db("imcDB").collection("marks");
    app.post("/test-marks", async (req, res) => {
      const formInfo = req.body;
      console.log(formInfo);
      const result = await marksCollection.insertOne(formInfo);
      res.send(result);
    });
    app.get("/test-marks/:id",async (req, res) => {
      const id = req.params.id
      const query = {testId : id}
      const allTest = await marksCollection.findOne(query);
      console.log(allTest);
      let newData = []
      for(var i = 0 ; i < allTest?.marksData?.length ; i++){
        const studentId = allTest.marksData[i]?.studentId ;
        console.log(studentId);
        const studentQuery = {_id : new ObjectId(studentId)}
        const studentData = await admissionCollection.findOne(studentQuery)
        console.log(studentData);
        const mainData = {studentData :studentData , mark :allTest.marksData[i]?.mark }
        newData.push(mainData)
      } 
      console.log(newData);
      res.send({data : newData , testId : allTest?.testId})
    })

    // marks code api end
    // addmission student api start
    const admissionCollection = client.db("imcDB").collection("admissions");
    app.post("/admissions", async (req, res) => {
        const formInfo = req.body;
        const result = await admissionCollection.insertOne(formInfo);
        res.send(result);
      });
      app.get("/admissions", async (req, res) => {
        const result = await admissionCollection.find().toArray();
        res.send(result)
      })
      app.get("/total-student-length", async (req, res) => {
        const result = await admissionCollection.countDocuments();
        res.send({length : result})
      })
      app.get("/total-student-batch", async (req, res) => {
        const {batch} = req.query ;
        const result = await admissionCollection.countDocuments({batch:batch , completedInfo : "running student"});
        res.send({length : result})
      })
      app.get("/batch-students", async (req, res) => {
        const {batch} = req.query ;
        const result = await admissionCollection.find({batch:batch, completedInfo : "running student"}).toArray();
        res.send(result)
      })
      app.get("/filter-admissions", async (req, res) => {
        const { name } = req.query; // Capture 'name' from query parameters
      
        // Build the search condition
        const query = {
          completedInfo: "running student", // Ensure 'completedInfo' matches 'runningApplication'
          ...(name && {
            $or: [       // Match courseName
              { batch: { $regex: name, $options: "i" } },         // Match batchTitle
              { name: { $regex: name, $options: "i" } },          // Match status
              { registrationNo: { $regex: name, $options: "i" } },// Match registrationNo
              { mobile: { $regex: name, $options: "i" } },        // Match mobile
              { birthOfDate: { $regex: name, $options: "i" } },   // Match birthOfDate
              { enrollDate: { $regex: name, $options: "i" } },   // Match birthOfDate
            ],
          }),
        };
      
        try {
          // Query the database based on the search conditions
          const result = await admissionCollection.find(query).sort({ date: -1 }).toArray();
          res.send(result); // Send the filtered records as the response
        } catch (error) {
          console.error(error);
          res.status(500).send({ error: "Failed to fetch admissions" });
        }
      });
      app.get("/admissions/:id", async (req, res) => {
        const query = req.params.id ;
        const filter = { _id: new ObjectId(`${query}`) }
        const result = await admissionCollection.findOne(filter)
        res.send(result)
      })
      app.delete("/admissions-delete/:id", async (req, res) => {
        const query = req.params.id ;
        const filter = { _id: new ObjectId(query) }
        
        const updateDoc = {
       
            $set: {
     completedInfo : "deleted"
             
              
            },
          };
        const result = await admissionCollection.updateOne(filter , updateDoc )
        res.send(result)
      })
      app.put('/admissions/:id' , async(req , res) => {
        const id = req.params.id ;
        const filter = { _id :new ObjectId(id) }
        const update = req.body ;
        
        const updateDoc = {
       
            $set: {
              name:  update.name,
              fathersOrHusbandName:  update.fathersOrHusbandName,
              fathersNumber:  update.fathersNumber,
              fathersOccupation:  update.fathersOccupation,
              mothersName:  update.mothersName,
              mothersNumber:  update.mothersNumber,
              mothersOccupation:  update.mothersOccupation,
              gender:  update.gender,
              dateOfBirth:  update.dateOfBirth,
              studentSchool:  update.studentSchool,
              studentSchoolRoll:  update.studentSchoolRoll,
              studentMonthlyFee:  update.studentMonthlyFee,
              mobile:  update.mobile,
              guardiansMobile:  update.guardiansMobile,      
              photoURL:  update.photoURL,
              presentAddress:  update.presentAddress,
              permanentAddress:  update.permanentAddress, 
              batch:  update.batch,
              enrollDate:  update.enrollDate,
              bloodGroup:  update.bloodGroup,
              rollNo:  update.rollNo,
           
             
              
            },
          };
        const result = await admissionCollection.updateOne(filter , updateDoc )
        res.send(result)
    })
      app.get("/studentDetails", async (req, res) => {
        const query = req.query.id ;
        console.log(query);
        const filter = { _id: new ObjectId(query) }
        const result = await admissionCollection.findOne(filter)
        res.send(result)
      })
      app.get("/admissions/registration-number-check/:id", async (req, res) => {
        const query = req.params.id;
        console.log(query);
        
        // Use findOne to directly query the student with matching registrationNo
        const findStudent = await admissionCollection.findOne({ registrationNo: query });
        
        if (findStudent) {
          console.log("Student found:", findStudent);
          res.send({ result: true });
        } else {
          console.log("Student not found");
          res.send({ result: false });
        }
      })
      app.get("/admissions/roll-number-check/:id", async (req, res) => {
        const query = req.params.id;
        console.log(query);
        
        // Use findOne to directly query the student with matching registrationNo
        const findStudent = await admissionCollection.findOne({ registrationNo: query });
        
        if (findStudent) {
          console.log("Student found:", findStudent);
          res.send({ result: true });
        } else {
          console.log("Student not found");
          res.send({ result: false });
        }
      
      })

      app.patch("/studentDetails/:id",  async (req, res) => {
        const details = req.body;
        const query = req.params.id ;
        const cursor = {  _id :new ObjectId(query)};
        console.log(details , cursor);
        const updatedDoc = {
          $set: {
            name: details.name,
            studentClass: details.studentClass,
            parentsPhoneNumber: details.parentsPhoneNumber,
            admissionDate: details.admissionDate,
            batch: details.batch,
            school: details.school,
            message: details.message,
            dueMonth: details.dueMonth,
            
          },
        };
        const result = await admissionCollection.updateOne(cursor, updatedDoc);
        res.send(result);
      });
    // addmission student api end
    // all student api start
    const allStudentCollection = client.db("imcDB").collection("allStudent");
    app.get("/studentFilter", async (req, res) => {
      const filter = req.query ;
      console.log(filter);
    const query = {
      id :{$regex : filter.id } ,
      name : {$regex : filter.name , $options : 'i'},
      studentClass : {$regex : filter.studentClass }
    }
    const result = await admissionCollection.find(query).toArray();
    res.send(result)
  })
    app.get("/studentClassFilter", async (req, res) => {
      const filter = req.query ;
      console.log(filter);
    const query = {
      studentClass : {$regex : filter.studentClass }
    }
    const result = await admissionCollection.find(query).toArray();
    res.send(result)
    
      
    })
//     cron.schedule("* * * * *", async () => {
//     console.log("Test cron job running...");
//     // Your update logic here
// });
    // all student api end
    // addpayment api start
    const paymentCollection = client.db("imcDB").collection("payments");
    // Bangladesh Time Cron Job
    cron.schedule("0 0 0 1 * *", async () => {
      try {
          // Get the current time in Bangladesh
          const bangladeshMonth = moment().tz("Asia/Dhaka").format("MMM YYYY");
    
          // Fetch all students from the admissions collection
          const students = await admissionCollection.find({}).toArray();
    
          // Prepare bulk write operations
          const bulkOperations = [];
    
          for (const student of students) {
              // Get the student batch
              const { batch, studentMonthlyFee } = student;
    
              // Retrieve the batch details to get the monthlyExamFee
              const studentBatch = await batchCollection.findOne({ batchTitle: batch });
    
              if (!studentBatch) {
                  console.warn(`Batch not found for student with ID: ${student._id}`);
                  continue; // Skip this student if no matching batch is found
              }
    
              const { batchMonthlyFee } = studentBatch;
    
              // Push the duesMonth entry
           const studentUpdate = await   admissionCollection.updateOne( { _id: student?._id }, {
                $push: {
                    duesMonth: {
                        month: bangladeshMonth,
                        fee: studentMonthlyFee, // Student's unique monthly fee // Batch-specific monthly exam fee
                    },
                    duesBatchMonthlyFee : {
                      month: bangladeshMonth,
                        fee: batchMonthlyFee, // Student's unique monthly fee

                    }
                }
            });
          }
    

      } catch (error) {
          console.error("Cron Job Error:", error);
      }
    }, {
      timezone: "Asia/Dhaka", // Set timezone to Bangladesh
    });
    
    

app.get("/filter-payments", async (req, res) => {
  const { name } = req.query; // Capture 'name' and 'transmittedDate' from query parameters

  try {
    const fees = await paymentCollection.find().sort({ date: -1 }).toArray();
    const currentStudents = await admissionCollection.find().toArray();

    // Perform data transformation or join operation
    const transformedData = fees.map(fee => {
      const studentInfo = currentStudents.find(student => student.registrationNo === fee.registrationNo);
      if (studentInfo) {
        const { _id,registrationNo, ...std } = studentInfo; // Exclude `_id` field from the student info
        return { ...fee, ...std };
      }
      return fee;
    });

    // Build the search conditions
    const regexConditions = name
      ? [
          { field: "category", regex: new RegExp(name, "i") },
          { field: "enrollDate", regex: new RegExp(name, "i") },
          { field: "date", regex: new RegExp(name, "i") },
          { field: "batch", regex: new RegExp(name, "i") },
          { field: "name", regex: new RegExp(name, "i") },
          { field: "registrationNo", regex: new RegExp(name, "i") },
          { field: "mobile", regex: new RegExp(name, "i") },
          { field: "birthOfDate", regex: new RegExp(name, "i") },
        ]
      : [];

    // Filter the transformed data based on the conditions
    const filteredData = transformedData.filter(item => {
      // Apply `name` filter
      const matchesName = name
        ? regexConditions.some(condition => condition.regex.test(item[condition.field]))
        : true;


     

      return matchesName ;
    });

    res.send(filteredData); // Send the filtered records as the response
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "Failed to fetch fees" });
  }
});
app.post("/payment", async (req, res) => {
  const formInfo = req.body;
  const registrationNo = formInfo?.registrationNo;
  const months = formInfo?.duesMonth; // Array of objects like [{ month: "January", fee: 100 }, ...]
  const monthlyFees = formInfo?.duesMonthlyFee; // Array of objects like [{ month: "January", fee: 100 }, ...]

  try {
    // Update the admission collection
    const updateResult = await admissionCollection.updateOne(
      { registrationNo: registrationNo }, // Match student by registration number
      {
        $push: { feesReceivedMonth: { $each: months }, feesReceivedBatchMonthlyFee: { $each: monthlyFees } }, // Add to feesReceivedMonth
        $pull: { duesMonth: { $in: months } ,duesBatchMonthlyFee: { $in: monthlyFees } }, // Remove matching objects from duesMonth
      },

    );

    // Insert into payment collection
    const result = await paymentCollection.insertOne(formInfo);

    res.send({ updateResult, paymentResult: result });
  } catch (error) {
    console.error("Error processing payment:", error);
    res.status(500).send({ error: "An error occurred while processing the payment." });
  }
});

    app.delete("/payment/:id", async (req, res) => {
      const id = req.params.id
      const searchQuery = {_id : new ObjectId(id)}
      const transection = await paymentCollection.findOne(searchQuery)
      const registrationNo = transection?.registrationNo
      const months = transection?.duesMonth 
      const monthlyFees = transection?.duesMonthlyFee;
      const updateResult = await admissionCollection.updateOne(
        { registrationNo: registrationNo }, // Match student by registration number
        {
            $pull: { feesReceivedMonth: { $in: months },feesReceivedBatchMonthlyFee: { $in: monthlyFees }  }, // Add to feesReceivedMonth
            $push: { duesMonth: { $each: months },duesBatchMonthlyFee: { $each: monthlyFees } } // Remove from duesMonth
        }
    );
    const result = await paymentCollection.deleteOne(searchQuery);
      res.send(result);
    });
    app.get("/addpayment", async (req, res) => {
      const result = await paymentCollection.find().toArray();
      res.send(result)
    })
    app.get("/payment-count", async (req, res) => {
      const result = await paymentCollection.countDocuments();
      res.send({length :result})
    })
    // addpayment api end
    // Send a ping to confirm a successful connection
    // await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");
  } finally {
    // Ensures that the client will close when you finish/error
    // await client.close();
  }
}
run().catch(console.dir);

app.get('/',( req , res) =>{
    res.send("database coming soon")
})

app.listen(port , (req , res) =>{
    console.log(`database is running successfully in port : ${port}`);
})